-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2022 at 04:29 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banco_locadora`
--

-- --------------------------------------------------------

--
-- Table structure for table `agendamento`
--

CREATE TABLE `agendamento` (
  `id_agendamento` int(11) NOT NULL,
  `nome` varchar(90) NOT NULL,
  `data_visita` varchar(10) NOT NULL,
  `horario` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `agendamento`
--

INSERT INTO `agendamento` (`id_agendamento`, `nome`, `data_visita`, `horario`) VALUES
(1, 'Thais Vitoria', '29/12/2022', '13:00');

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `cnh` int(11) NOT NULL,
  `endereco` varchar(120) NOT NULL,
  `telefone` varchar(21) NOT NULL,
  `email` varchar(90) NOT NULL,
  `idade` int(11) NOT NULL,
  `sexo` varchar(1) DEFAULT NULL,
  `user` varchar(45) NOT NULL,
  `senha` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`id_cliente`, `nome`, `cpf`, `cnh`, `endereco`, `telefone`, `email`, `idade`, `sexo`, `user`, `senha`) VALUES
(1, 'Thais Vitoria', '871.654.258-43', 1402987341, 'Rua da Consolação, 210, Centro, Belo Horizonte - MG', '(31)981593217', 'thaisvitoria@gmail.com', 26, 'F', 'thais@222', ''),
(2, 'João Carvalho', '452.654.614-25', 1164127868, 'Rua Guará, 256, Bairro Copacabana, Belo Horizonte - MG', '(31)982556984', 'joaocarvalho@gmail.com', 35, 'M', 'joao256#', 'joaocopacabana123');

-- --------------------------------------------------------

--
-- Table structure for table `funcionario`
--

CREATE TABLE `funcionario` (
  `id_funcionario` int(11) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `endereco` varchar(120) NOT NULL,
  `telefone` varchar(21) NOT NULL,
  `email` varchar(90) NOT NULL,
  `idade` int(11) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `funcao` varchar(21) NOT NULL,
  `user` varchar(45) NOT NULL,
  `senha_acesso` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `funcionario`
--

INSERT INTO `funcionario` (`id_funcionario`, `nome`, `cpf`, `endereco`, `telefone`, `email`, `idade`, `sexo`, `funcao`, `user`, `senha_acesso`) VALUES
(1, 'Nikolas Gabriel Oliveira', '324.479.542-29', 'Rua Salinas, 325, Floresta, Belo Horizonte - MG', '(31)987412064', 'nikolas@maonaroda.com', 21, 'M', 'Gerente', 'admin_804', 'adminnikolas123'),
(2, 'Maria Eduarda', '354.266.941-35', 'Rua Mármore, 12, Venda Nova, Belo Horizonte - MG', '(31)992643622', 'mariaeduarda@maonaroda.com', 18, 'F', 'Gerente', 'admin_802', 'adminduda321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agendamento`
--
ALTER TABLE `agendamento`
  ADD PRIMARY KEY (`id_agendamento`),
  ADD UNIQUE KEY `id_agendamento_UNIQUE` (`id_agendamento`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id_cliente`),
  ADD UNIQUE KEY `id_cliente_UNIQUE` (`id_cliente`),
  ADD UNIQUE KEY `cnh_UNIQUE` (`cnh`),
  ADD UNIQUE KEY `cpf_UNIQUE` (`cpf`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `user_UNIQUE` (`user`),
  ADD UNIQUE KEY `telefone_UNIQUE` (`telefone`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`id_funcionario`),
  ADD UNIQUE KEY `id_funcionario_UNIQUE` (`id_funcionario`),
  ADD UNIQUE KEY `cpf_UNIQUE` (`cpf`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `telefone_UNIQUE` (`telefone`),
  ADD UNIQUE KEY `user_UNIQUE` (`user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agendamento`
--
ALTER TABLE `agendamento`
  MODIFY `id_agendamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `id_funcionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
