/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.FuncionarioDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author nikol
 */
public class FuncionarioDAO {
    
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<FuncionarioDTO> list = new ArrayList<>();
    
    public ResultSet autenticacaoFuncionario(FuncionarioDTO objfuncionariodto){
    
        conn = new ConexaoDAO().conectaBD();
        
        try {
            
            String sql = "select * from funcionario where user = ? and senha = ?";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objfuncionariodto.getUser());
            pstm.setString(2, objfuncionariodto.getSenha());
            
            ResultSet rs = pstm.executeQuery();
            return rs;
            
            
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "FuncionarioDAO: " + error);
            return null;
        }
        
    }
    
    
    public void cadastrarFuncionario(FuncionarioDTO objfuncionariodto) {
        
    String sql = "insert into funcionario (nome, cpf, endereco, telefone, email, idade, sexo, funcao, user, senha_acesso) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";    
    conn = new ConexaoDAO().conectaBD();
    
        try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objfuncionariodto.getNome());
            pstm.setString(2, objfuncionariodto.getCpf());
            pstm.setString(3, objfuncionariodto.getEndereco());
            pstm.setString(4, objfuncionariodto.getTelefone());
            pstm.setString(5, objfuncionariodto.getEmail());
            pstm.setInt(6, objfuncionariodto.getIdade());
            pstm.setString(7, objfuncionariodto.getSexo());
            pstm.setString(8, objfuncionariodto.getFuncao());
            pstm.setString(9, objfuncionariodto.getUser());
            pstm.setString(10, objfuncionariodto.getSenha_acesso());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "FuncionarioDAO" + error);
        }
    
    }
    
    public ArrayList<FuncionarioDTO> ListarFuncionario() {
    
        String sql = "select * from funcionario";
        conn = new ConexaoDAO().conectaBD();
        try {
            
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()){
                FuncionarioDTO objfFuncionarioDTO = new FuncionarioDTO();
                objfFuncionarioDTO.setId_funcionario(rs.getInt("id_funcionario"));
                objfFuncionarioDTO.setNome(rs.getString("nome"));
                objfFuncionarioDTO.setCpf(rs.getString("cpf"));
                objfFuncionarioDTO.setEndereco(rs.getString("endereco"));
                objfFuncionarioDTO.setTelefone(rs.getString("telefone"));
                objfFuncionarioDTO.setEmail(rs.getString("email"));
                objfFuncionarioDTO.setIdade(rs.getInt("idade"));
                objfFuncionarioDTO.setSexo(rs.getString("sexo"));
                objfFuncionarioDTO.setFuncao(rs.getString("funcao"));
                objfFuncionarioDTO.setUser(rs.getString("user")); 
                
                list.add(objfFuncionarioDTO);
            }
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "ListarFuncionarioDAO: " + error);
        }
        
        return list;
        
    }
}
