/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.UsuarioDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno_Tarde
 */
public class UsuarioDAO {
    
    
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<UsuarioDTO> list = new ArrayList<>();
    
    public ResultSet autenticacaoUsuario(UsuarioDTO objclientedto){
    
        conn = new ConexaoDAO().conectaBD();
        
        try {
            
            String sql = "select * from cliente where user = ? and senha = ?";
            
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objclientedto.getEmail());
            pstm.setString(2, objclientedto.getSenha());
            
            ResultSet rs = pstm.executeQuery();
            return rs;
            
            
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "UsuarioDAO: " + error);
            return null;
        }
        
    }
    
    public void cadastrarCliente(UsuarioDTO objclientedto) { 
        
    String sql = "insert into cliente (nome, cpf, endereco, telefone, email, idade, sexo, user, senha) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";    
    conn = new ConexaoDAO().conectaBD();
    
    try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objclientedto.getNome());
            pstm.setString(2, objclientedto.getCpf()); 
            pstm.setString(3, objclientedto.getEndereco());
            pstm.setString(4, objclientedto.getTelefone());
            pstm.setString(5, objclientedto.getEmail());
            pstm.setInt(6, objclientedto.getIdade());
            pstm.setString(7, objclientedto.getSexo());
            pstm.setString(8, objclientedto.getUser());
            pstm.setString(9, objclientedto.getSenha());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showInternalConfirmDialog(null, "ClienteDAO" + error);
        }
    
    }
    
    public ArrayList<UsuarioDTO> ListarCliente() {
    
        String sql = "select * from usuario";
        conn = new ConexaoDAO().conectaBD();
        try {
            
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while(rs.next()){
                UsuarioDTO objClienteDTO = new UsuarioDTO();
                objClienteDTO.setId_usuario(rs.getInt("id_usuario"));
                objClienteDTO.setNome(rs.getString("nome"));
                objClienteDTO.setCpf(rs.getString("cpf"));
                objClienteDTO.setTelefone(rs.getString("telefone"));
                objClienteDTO.setEmail(rs.getString("email"));
                objClienteDTO.setSexo(rs.getString("sexo"));
                
                list.add(objClienteDTO);
            }
            
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, "ListarClienteDAO: " + error);
        }
        
        return list;
        
    }
    
    public void alterarDados(UsuarioDTO objclientedto){
    
        String sql = "update cliente set nome = ?, cpf = ?, endereco = ?, telefone = ?, email = ?, idade = ?, sexo = ?, user = ?, senha = ? where id_cliente = ?";
    
         conn = new ConexaoDAO().conectaBD();
    
    try {
            
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objclientedto.getNome());
            pstm.setString(2, objclientedto.getCpf());
            pstm.setString(4, objclientedto.getTelefone());
            pstm.setString(5, objclientedto.getEmail());
            pstm.setString(7, objclientedto.getSexo());
            pstm.setString(9, objclientedto.getSenha());
            pstm.setInt(10, objclientedto.getId_usuario());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showInternalConfirmDialog(null, "ClienteDAO AlterarDados: " + error);
        }
        
    }
    
    public void ExcluirCliente(UsuarioDTO objusuariodto) {
    
        String sql = "select from cliente where id_usuario = ?";
    
         conn = new ConexaoDAO().conectaBD();
    
    try {
        
        pstm = conn.prepareStatement(sql);
            
        pstm.setInt(1, objusuariodto.getId_usuario());
        
        pstm.execute();
        pstm.close();
            
        } catch (SQLException error) {
            JOptionPane.showInternalConfirmDialog(null, "ClienteDAO ExcluirDados: " + error);
        }
    
    
    }
    
}
