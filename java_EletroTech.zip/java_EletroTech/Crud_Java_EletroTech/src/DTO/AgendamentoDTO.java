/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author nikol
 */
public class AgendamentoDTO {
    
    private int id_agendamento;
    
    private String nome;
    private String data_visita;
    private String horario;

    /**
     * @return the id_agendamento
     */
    public int getId_agendamento() {
        return id_agendamento;
    }

    /**
     * @param id_agendamento the id_agendamento to set
     */
    public void setId_agendamento(int id_agendamento) {
        this.id_agendamento = id_agendamento;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the data_visita
     */
    public String getData_visita() {
        return data_visita;
    }

    /**
     * @param data_visita the data_visita to set
     */
    public void setData_visita(String data_visita) {
        this.data_visita = data_visita;
    }

    /**
     * @return the horario
     */
    public String getHorario() {
        return horario;
    }

    /**
     * @param horario the horario to set
     */
    public void setHorario(String horario) {
        this.horario = horario;
    }
    
    
}
